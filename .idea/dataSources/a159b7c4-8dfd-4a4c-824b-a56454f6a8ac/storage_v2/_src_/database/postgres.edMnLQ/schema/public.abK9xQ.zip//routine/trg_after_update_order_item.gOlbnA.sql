create function trg_after_update_order_item() returns trigger
    language plpgsql
as
$$
DECLARE
    delta INT;
BEGIN
    -- Tính độ chênh giữa giá trị mới và cũ
    delta
        := NEW.quantity - OLD.quantity;

    IF
        delta <> 0 THEN
        -- 3.1 Cập nhật sold của variant
        UPDATE product_variants
        SET sold = sold + delta
        WHERE variant_id = NEW.variant_id;

-- 3.2 Cập nhật purchases của product
        UPDATE products
        SET purchases = purchases + delta
        FROM product_variants pv
        WHERE products.product_id = pv.product_id
          AND pv.variant_id = NEW.variant_id;
    END IF;

    RETURN NEW;
END;
$$;

alter function trg_after_update_order_item() owner to postgres;

