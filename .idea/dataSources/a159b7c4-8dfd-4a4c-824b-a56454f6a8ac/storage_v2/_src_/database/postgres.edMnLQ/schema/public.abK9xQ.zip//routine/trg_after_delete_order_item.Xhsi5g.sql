create function trg_after_delete_order_item() returns trigger
    language plpgsql
as
$$
BEGIN
    -- 5.1 Trừ số lượng đã xóa khỏi sold
    UPDATE product_variants
    SET sold = sold - OLD.quantity
    WHERE variant_id = OLD.variant_id;

-- 5.2 Trừ khỏi purchases của product
    UPDATE products
    SET purchases = purchases - OLD.quantity
    FROM product_variants pv
    WHERE products.product_id = pv.product_id
      AND pv.variant_id = OLD.variant_id;

    RETURN OLD;
END;
$$;

alter function trg_after_delete_order_item() owner to postgres;

