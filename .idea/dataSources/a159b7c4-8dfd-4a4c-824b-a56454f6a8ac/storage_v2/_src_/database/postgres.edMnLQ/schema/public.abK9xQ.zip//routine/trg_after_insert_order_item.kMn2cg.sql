create function trg_after_insert_order_item() returns trigger
    language plpgsql
as
$$
BEGIN
    -- 1.1 Cộng số lượng bán vào trường sold của variant
    UPDATE product_variants
    SET sold = sold + NEW.quantity
    WHERE variant_id = NEW.variant_id;

-- 1.2 Cộng số lượng bán vào trường purchases của product
    UPDATE products
    SET purchases = purchases + NEW.quantity
    FROM product_variants pv
    WHERE products.product_id = pv.product_id
      AND pv.variant_id = NEW.variant_id;

    RETURN NEW;
END;
$$;

alter function trg_after_insert_order_item() owner to postgres;

